
### 1.3.7 - 18/08/2016
**Changes:** 
- Fixed masonry issue with WordPress 4.6


### 1.3.6 - 20/11/2015

 Changes: 


 * Fixed #26 The number of articles displayed wrong in Firefox


### 1.3.5 - 08/09/2015

 Changes: 


 * Updated pot file with latest articles


### 1.3.4 - 21/08/2015

 Changes: 


 * #36 - added space between logo and nav
 * #36 - remove double menu
 * Merge pull request #38 from cristian-ungureanu/development

Development


### 1.3.4 - 20/08/2015

 Changes: 


 * Update class-tgm-plugin-activation to latest version
 * Update style.css
 * added action hook for socials
 * plugin compatibility
 * added compatibility with customizer plugin
 * fixed metro customizr presentation page
 * added transport postmessage to logo
 * added transport post message for colors
 * Merge pull request #30 from cristian-ungureanu/development

Development
 * #31 - Added image license
 * #31 - change functions prefix
 * change hook names back
 * add plugin link to metro customizr page
 * Merge pull request #32 from cristian-ungureanu/development

Development
 * this fixes #34 - view theme button
 * #33 - fix theme check errors
 * #31 - added licence to customizr_logo.jpg and change links to images
 * Merge pull request #35 from cristian-ungureanu/development

Development


### 1.3.3 - 01/07/2015

 Changes: 


 * Escaped values from customizer


### 1.3.2 - 23/06/2015

 Changes: 


 * Added custom colors support


### 1.3.0 - 24/04/2015

 Changes: 


 * Fixed #22, masonry console error


### 1.2.9 - 30/03/2015

 Changes: 


 * Date issue fixed

Fixed issue with date which was causing a lot of sites to display same
date on all the posts.

Issue: https://github.com/Codeinwp/metro-creativex/issues/19
 * Merge pull request #20 from HardeepAsrani/development

Date issue fixed


### 1.2.8 - 05/03/2015

 Changes: 


 * Replaced screenshot
 * Merge pull request #15 from DragosBubu/development

Replaced screenshot
 * Changed screenshot


### 1.2.6 - 30/12/2014

 Changes: 


 * added tgm activation


### 1.2.5 - 08/12/2014

 Changes: 


 * Removed tinynav never used, fixed prefix issues
 * Removed tinynav
 * Added forum link in description and added sanitize for customizer
 * added text domain
 * increased vers


### 1.2.3 - 17/10/2014

 Changes: 


 * Update style.css


### 1.2.2 - 17/10/2014

 Changes: 


 * Update style.css


### 1.2.1 - 17/10/2014

 Changes: 


 * Update style.css
